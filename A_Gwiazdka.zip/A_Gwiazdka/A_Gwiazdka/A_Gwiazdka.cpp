﻿#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

class Wezel {
public:
    int posX, posY;
    double kosztPrzejscia, kosztHeurystyczny, calkowityKoszt;
    Wezel* nodeRodzic;

    Wezel(int x, int y) : posX(x), posY(y), kosztPrzejscia(0), kosztHeurystyczny(0), calkowityKoszt(0), nodeRodzic(nullptr) {}

    void ObliczHeurystyke(int celX, int celY) {
        kosztHeurystyczny = sqrt((celX - posX) * (celX - posX) + (celY - posY) * (celY - posY));
        ZaktualizujKoszt();
    }

    void ZaktualizujKoszt() {
        calkowityKoszt = kosztPrzejscia + kosztHeurystyczny;
    }
};

Wezel* WykonajAStar(int poczatekX, int poczatekY, int celX, int celY, int maxSzer, int maxWys, double** Mapa);
bool JestDostepny(int x, int y, int maxSzer, int maxWys, double** Mapa);
vector<Wezel*> ZnajdzSasiadow(Wezel* aktualny, int maxSzer, int maxWys, double** Mapa);
void OznaczSciezke(Wezel* sciezka, double** Mapa);

int main(void) {
    cout << "Wczytywanie mapy\n";

    string nazwaPliku = "grid.txt";
    int wysokosc = 19;
    int szerokosc = 19;


    int rows = wysokosc + 1;
    double** Mapa;
    Mapa = new double* [rows];


    for (int i = 0; i < rows; ++i) {
        Mapa[i] = new double[szerokosc + 1];
    }


    cout << "\n\nNacisnij ENTER aby wczytac tablice o nazwie " << nazwaPliku;
    getchar();

    ifstream plik(nazwaPliku.c_str());
    for (int i = 0; i <= wysokosc; ++i) {
        for (int j = 0; j <= szerokosc; ++j) {
            plik >> Mapa[i][j];
        }
    }
    plik.close();


    cout << "\nMapa z pliku: " << nazwaPliku << "\n\n";
    for (int i = 0; i <= wysokosc; i++) {
        for (int j = 0; j <= szerokosc; j++) {
            cout << " " << Mapa[i][j];
        }
        cout << "\n";
    }

    int startX = 0;
    int startY = 19;
    int celX = 19;
    int celY = 0;

    Wezel* wynik = WykonajAStar(startX, startY, celX, celY, szerokosc, wysokosc, Mapa);

    if (wynik != nullptr) {
        cout << "\nZnaleziono sciezke:\n";
        OznaczSciezke(wynik, Mapa);
        cout << "\nMapa z zaznaczona sciezka (sciezka jest oznaczona cyfra 3): \n\n";

        for (int i = 0; i <= wysokosc; i++) {
            for (int j = 0; j <= szerokosc; j++) {
                cout << " " << Mapa[i][j];
            }
            cout << "\n";
        }
    }
    else {
        cout << "\nNie znaleziono sciezki.\n";
    }

    // Czyszczenie pamięci po tablicy
    for (int i = 0; i <= wysokosc; i++) {
        delete[] Mapa[i];
    }
    delete[] Mapa;

    cout << "\n\nNacisnij ENTER aby zakonczyc";
    getchar();

    return 0;
}

bool JestDostepny(int x, int y, int maxSzer, int maxWys, double** Mapa) {
    if (x >= 0 && x <= maxSzer && y >= 0 && y <= maxWys && Mapa[y][x] == 0) {
        return true;
    }
    else {
        return false;
    }
}

void OznaczSciezke(Wezel* sciezka, double** Mapa) {
    cout << "\nSciezka:\n";

    vector<Wezel*> odwroconaSciezka;
    while (sciezka != nullptr) {
        odwroconaSciezka.push_back(sciezka);
        sciezka = sciezka->nodeRodzic;
    }

    for (int i = odwroconaSciezka.size() - 1; i >= 0; --i) {
        Mapa[odwroconaSciezka[i]->posY][odwroconaSciezka[i]->posX] = 3;
        cout << "Krok: " << odwroconaSciezka.size() - i << " (" << odwroconaSciezka[i]->posX << ", " << odwroconaSciezka[i]->posY << ")\n";
    }
}

vector<Wezel*> ZnajdzSasiadow(Wezel* aktualny, int maxSzer, int maxWys, double** Mapa) {
    vector<Wezel*> dostepnePola;
    int dx[] = { 0, 0, -1, 1 };
    int dy[] = { -1, 1, 0, 0 };

    for (int i = 0; i < 4; ++i) {
        int nowyX = aktualny->posX + dx[i];
        int nowyY = aktualny->posY + dy[i];

        if (JestDostepny(nowyX, nowyY, maxSzer, maxWys, Mapa)) {
            Wezel* nowyWezel = new Wezel(nowyX, nowyY);
            nowyWezel->nodeRodzic = aktualny; // Ustawiamy rodzica dla nowego węzła
            dostepnePola.push_back(nowyWezel);
        }
    }

    return dostepnePola;
}

Wezel* WykonajAStar(int poczatekX, int poczatekY, int celX, int celY, int maxSzer, int maxWys, double** Mapa) {
    vector<Wezel*> otwartaLista;
    vector<Wezel*> zamknietaLista;

    Wezel* start = new Wezel(poczatekX, poczatekY);
    start->ObliczHeurystyke(celX, celY);
    otwartaLista.push_back(start);

    while (!otwartaLista.empty()) {
        Wezel* obecny = otwartaLista[0];
        int indeksAktualnego = 0;

        // f wybierz pole z lisy otwartej z najnizszym kosztem
        for (int i = 0; i < otwartaLista.size(); ++i) {
            if (otwartaLista[i]->calkowityKoszt <= obecny->calkowityKoszt) {
                obecny = otwartaLista[i];
                indeksAktualnego = i;
            }
        }


        // f sprawdz czy to jest celcel
        if (obecny->posX == celX && obecny->posY == celY) {
            return obecny; // Znaleziono cel
        }

        // wywal obecnego z otwartej listy i dodaj do zamknietej listy czyli listy
        otwartaLista.erase(otwartaLista.begin() + indeksAktualnego);
        zamknietaLista.push_back(obecny);


        vector<Wezel*> sasiedzi = ZnajdzSasiadow(obecny, maxSzer, maxWys, Mapa);
        for (Wezel* sasiad : sasiedzi) {
            bool pomin = false;

            //czy sasiad nie jest sciezka
            for (Wezel* zamkniety : zamknietaLista) {
                if (sasiad->posX == zamkniety->posX && sasiad->posY == zamkniety->posY) {
                    pomin = true;
                    break;
                }
            }
            if (pomin) continue;

            double nowyKosztG = obecny->kosztPrzejscia + 1;

            // czy sasiad byl juz rozpatrywany i czy jego stary koszt jest wiekszy/mniejszy od nowego kosztu
            bool czyOtwarty = false;
            for (Wezel* otwarty : otwartaLista) {
                if (sasiad->posX == otwarty->posX && sasiad->posY == otwarty->posY && nowyKosztG >= otwarty->kosztPrzejscia) {
                    czyOtwarty = true;
                    break;
                }
            }

            //oblicz koszt dla sasiada i dodaj go do otwartej listy
            if (!czyOtwarty) {
                sasiad->kosztPrzejscia = nowyKosztG;
                sasiad->ObliczHeurystyke(celX, celY);
                otwartaLista.push_back(sasiad);
            }
        }
    }
    return nullptr;
}